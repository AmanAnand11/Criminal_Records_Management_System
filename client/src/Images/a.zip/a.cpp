#include <bits/stdc++.h>
// #include <atcoder/dsu>
#define all(x) x.begin(), x.end()
using namespace std;
// using namespace atcoder;
typedef vector<int> vi;
typedef long long ll;
typedef vector<ll> vll;
typedef pair<int, int> pii;
const long long N = 1e18;
 
template <typename T>
void print(const vector<T>& v) {
    for (int i = 0; i < v.size(); i++) cout << v[i] << ' ';
    cout << '\n';
}
 
template <typename T>
void read(vector<T>& v, ll j, ll n) {
    for (ll i = j; i < n; i++) {
        cin >> v[i];
    }
}
 
 
template <typename T>
void print2dArray(const vector<vector<T>>& dp, string separator = " ") {
    int m{dp.size()}, n(dp[0].size());
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cout << dp[i][j] << separator;
        }
        cout << endl;
    }
}
 
template <typename T>
void print(T a) {
    cout << a << endl;
}




int main() {
    ll n, m; cin >> n >> m;
    
    vector<vector<pair<ll, ll>>> g(n + 1);

    for (int i = 1; i <= m; i++) {
        ll a, b, c;
        cin >> a >> b >> c;
        g[a].push_back({c, b});
    }

    // bellman - ford
    // proof in jessica su's cs161 notes

    vector<ll> dist(n + 1, N);
    dist[1] = 0;

    vector<ll> parent(n + 1, -1);

    for (int i = 1; i < n; i++) {
        for (int u = 1; u <= n; u++) {
            for (auto& [w, v] : g[u]) {
                if (dist[v] > dist[u] + w) {
                    dist[v] = dist[u] + w;
                    parent[v] = u;
                }
            }
        }
    }

    // print(dist);
    bool negativeCycle = false;

    ll startsAt = -1;
    for (int u = 1; u <= n; u++) {
        if (dist[u] != N) {
            for (auto& [w, v] : g[u]) {
                if (dist[v] > dist[u] + w) {
                    negativeCycle = true;
                    startsAt = v;
                }
            }
        }
    }

    if (negativeCycle) {
        print("YES");
        // print(parent);
        // print(startsAt);
        ll k = startsAt;
        vector<ll> ans;
        ans.push_back(startsAt);
        while (parent[startsAt] != k) {
            startsAt = parent[startsAt];
            ans.push_back(startsAt);
        }
        ans.push_back(k);
        print(ans);
    } else {
        print("NO");
    }

}
/*

  

*/